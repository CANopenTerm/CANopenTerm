#define VERSION_MAJOR		4
#define VERSION_MINOR		6
#define VERSION_PATCH		1
#define VERSION_BUILD		0

#define FILEVER 4,6,1,0
#define STRFILEVER "4.6.1.0"
#define STRPRODUCTVER "4.6"
#define COPYRIGHT "Copyright © 2022 PEAK-System Technik GmbH"
