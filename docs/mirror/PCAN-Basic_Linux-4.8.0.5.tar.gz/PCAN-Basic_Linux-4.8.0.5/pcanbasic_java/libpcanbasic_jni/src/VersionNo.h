#define FILEVER 4,8,1,7
#define STRFILEVER "4.8.1.7"
#define STRPRODUCTVER "4.8"
#define COPYRIGHT "(C) 2023 PEAK-System Technik GmbH"
// linux API
#define VERSION_MAJOR		4
#define VERSION_MINOR		8
#define VERSION_PATCH		1
#define VERSION_BUILD		7

